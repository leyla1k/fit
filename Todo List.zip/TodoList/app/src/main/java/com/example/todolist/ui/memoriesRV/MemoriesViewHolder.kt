package com.example.todolist.ui.memoriesRV

import androidx.recyclerview.widget.RecyclerView
import com.example.todolist.databinding.ItemMemoryBinding
import com.example.todolist.entities.Project
import com.example.todolist.databinding.ItemProjectBinding
import com.example.todolist.entities.Memory
import java.text.DateFormat

class MemoriesViewHolder(val binding: ItemMemoryBinding) : RecyclerView.ViewHolder(binding.root) {
    fun onBind(item: Memory) {
        with(binding) {


        }
    }
}