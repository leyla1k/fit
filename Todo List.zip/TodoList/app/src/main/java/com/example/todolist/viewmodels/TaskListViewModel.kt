package com.example.todolist.viewmodels

import androidx.lifecycle.ViewModel
import com.example.todolist.database.ProjectsRepository

class TaskListViewModel(val projectsRepository: ProjectsRepository) : ViewModel() {
    // TODO: Implement the ViewModel
}