package com.example.todolist.entities

import java.util.Date

data class Memory(val id: String,
             val date: Date?,
            )