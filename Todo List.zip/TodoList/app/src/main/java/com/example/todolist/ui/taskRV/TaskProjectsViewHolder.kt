package com.example.todolist.ui.taskRV

import androidx.recyclerview.widget.RecyclerView
import com.example.todolist.databinding.ItemTaskBinding
import com.example.todolist.entities.Task

class TaskProjectsViewHolder(val binding: ItemTaskBinding) : RecyclerView.ViewHolder(binding.root) {
    fun onBind(item: Task) {
        with(binding) {

        }
    }
}