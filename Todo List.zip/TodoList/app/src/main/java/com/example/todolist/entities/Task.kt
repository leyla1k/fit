package com.example.todolist.entities

import java.util.Date

data class Task (val id: String,
                 val name:String,
                 )