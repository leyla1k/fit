package com.example.todolist

val PROVIDER_NAME = "com.example.todolist.provider"