package com.example.todolist.ui.alertDialogs

interface DialogListener {
        fun onFinishDialog(data: String)
}